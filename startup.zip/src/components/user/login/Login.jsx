import { Link } from "react-router-dom";
import {  FaEnvelope, FaLock, FaEye } from "react-icons/fa";
import "./login.css";

export default function Login() {
  return (
    <section className="login-section">

      <div className="login-card shadow">

        <div className="text-center mb-4">

         

          <h2>Welcome Back</h2>

          <p>
            Sign in to startuphub
          </p>

        </div>

        <form>

          <div className="input-group-custom">

            <FaEnvelope className="input-icon"/>

            <input
              type="email"
              placeholder="Email Address"
              className="form-control"
            />

          </div>

          <div className="input-group-custom mt-4">

            <FaLock className="input-icon"/>

            <input
              type="password"
              placeholder="Password"
              className="form-control"
            />

            <FaEye className="eye-icon"/>

          </div>

          <br />

          <button className="btn login-btn w-100">
            Login
          </button>

        </form>

        <p className="text-center mt-4">

          Don't have an account?

          <Link to="/signup" className="ms-2">
            Create Account
          </Link>

        </p>

      </div>

    </section>
  );
}