import Header from "./Header";
import Footer from "./Footer";
import Breadcrumb from "../../shared/Breadcrumb";
import { Outlet, useLocation } from "react-router-dom";

export default function Layout() {

  const location = useLocation();

  // Pages where breadcrumb should NOT appear
  const hideBreadcrumb = location.pathname === "/";

  return (
    <>
      <Header />

      {!hideBreadcrumb && <Breadcrumb />}

      <Outlet />

      <Footer />
    </>
  );
}