import Hero from "./Hero";

export default function Home() {
  return (
    <>
      <Hero />

      {/* Features */}

      {/* Your existing feature section */}

      {/* About */}

      {/* Services */}

      {/* Team */}

      {/* Testimonials */}

      {/* Footer */}
    </>
  );
}