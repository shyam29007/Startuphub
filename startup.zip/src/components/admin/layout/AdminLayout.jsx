import { Outlet } from 'react-router-dom'


import AdminHeader from "./AdminHeader";
import AdminFooter from "./AdminFooter";
import AdminBreadcrumb from "./AdminBreadcrumb"


export default function AdminLayout(){
    return(
        <>
            <AdminHeader></AdminHeader>
            <AdminBreadcrumb />

           <div className="container-fluid py-5">
             <Outlet></Outlet>
        </div>

            <AdminFooter></AdminFooter>

        </>
    )
}