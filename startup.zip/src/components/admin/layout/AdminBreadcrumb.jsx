import { Link, useLocation } from "react-router-dom";
import "../styles/AdminBreadcrumb.css";
import breadcrumbImg from "../../../assets/hero.png";

export default function AdminBreadcrumb() {
  const { pathname } = useLocation();

  let title = "Dashboard";

  if (pathname === "/admin") {
    title = "Dashboard";
  } else if (pathname.includes("/categories")) {
    title = "Manage Categories";
  } else if (pathname.includes("/category/add")) {
    title = "Add Category";
  } else if (pathname.includes("/category/edit")) {
    title = "Edit Category";
  }

  return (
    <section
      className="admin-breadcrumb"
      style={{
        backgroundImage: `linear-gradient(rgba(0,0,0,.6), rgba(0,0,0,.6)), url(${breadcrumbImg})`,
      }}
    >
      <div className="admin-overlay">
        <div className="container text-center">

          <h1>{title}</h1>

          <nav>
            <Link to="/admin">Dashboard</Link>

            {pathname !== "/admin" && (
              <>
                <span>/</span>
                <span>{title}</span>
              </>
            )}
          </nav>

        </div>
      </div>
    </section>
  );
}