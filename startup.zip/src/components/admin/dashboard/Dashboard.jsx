export default function Dashboard() {
  return (
    <>
    <div className="container py-5">
      <h1>Admin Dashboard</h1>
      <p>Welcome to StartupHub Admin Panel</p>
    </div>
    
    
    </>
    
  );
}