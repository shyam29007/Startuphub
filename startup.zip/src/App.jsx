import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import Layout from "./components/user/layout/Layout";

import Home from "./components/user/Home";
import Contact from "./components/user/contact/Contact";
import About from "./components/user/about/About";
import Login from "./components/user/login/Login";

import AdminLayout from "./components/admin/layout/AdminLayout";
import Dashboard from "./components/admin/dashboard/Dashboard";
import ManageCategories from "./components/admin/category/ManageCategories";
import AddCategory from "./components/admin/category/AddCategory";
import EditCategory from "./components/admin/category/EditCategory";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>

        {/* User Routes */}
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="contact" element={<Contact />} />
          <Route path="about" element={<About />} />
          <Route path="login" element={<Login />} />
        </Route>

        {/* Admin Routes */}
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="categories" element={<ManageCategories />} />
          <Route path="category/add" element={<AddCategory />} />
          <Route path="category/edit/:id" element={<EditCategory />} />
        </Route>

      </Routes>

      <ToastContainer />
    </BrowserRouter>
  );
}