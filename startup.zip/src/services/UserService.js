import { doc, setDoc } from "firebase/firestore";

import { db } from "../firebase/firebase";

export const createUser = async (user) => {
  try {
    await setDoc(doc(db, "users", user.uid), user);

    return {
      success: true,
    };
  } 
  catch (error) {
    console.log(error);

    return {
      success: false,
      message: error.message,
    };
  }
};